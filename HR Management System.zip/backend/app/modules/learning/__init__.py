"""Learning Module"""
