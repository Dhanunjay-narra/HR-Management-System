"""Assets Module"""
